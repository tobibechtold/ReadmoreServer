package de.readmoreserver.data.beans;

public enum RMStatus {
	
	SICHTBAR,
	UNSICHTBAR;

}
