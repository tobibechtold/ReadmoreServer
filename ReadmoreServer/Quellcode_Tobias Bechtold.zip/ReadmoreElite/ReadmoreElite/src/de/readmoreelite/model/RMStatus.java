package de.readmoreelite.model;

public enum RMStatus {
	
	SICHTBAR,
	UNSICHTBAR,
	READ,
	UNREAD,
	STICKY_READ,
	STICKY_UNREAD;
}
