//package de.readmoreelite.data;
//import java.io.BufferedReader;
//import java.io.DataOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.UnsupportedEncodingException;
//import java.net.CookieHandler;
//import java.net.CookieManager;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.net.URLEncoder;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//import javax.net.ssl.HttpsURLConnection;
//
//import org.apache.http.Header;
//import org.apache.http.HttpEntity;
//import org.apache.http.HttpResponse;
//import org.apache.http.NameValuePair;
//import org.apache.http.client.HttpClient;
//import org.apache.http.client.entity.UrlEncodedFormEntity;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.message.BasicNameValuePair;
//import org.apache.http.util.EntityUtils;
//import org.jsoup.Connection;
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//
//public class HttpTest {
//
//	private List<String> cookies = new ArrayList<String>();
//
//	private final String USER_AGENT = "Mozilla/5.0";
//	private static String page;
//	private static String url;
//	private HttpClient client = HttpClients.createDefault();;
//
//	public static void main(String[] args) throws Exception {
//
//		url = "http://www.readmore.de/forums/94-trashtalk/95-trashtalk/136574-fussball-liveticker-alles-um-den-sport-1-trashedition";
//		String url2 = "http://www.readmore.de/users/login";
//		String gmail = "http://www.readmore.de/users";
//
//		HttpTest http = new HttpTest();
//
//		// make sure cookies is turn on
//		CookieHandler.setDefault(new CookieManager());
//
//		String page2 = http.GetPageContent(url2);
//		List<NameValuePair> loginParams = http.getFormParams(page2,
//				"tobi.bechtold@gmail.com", "tobiasb1");
//
//		// 2. Construct above post's content and then send a POST request for
//		// authentication
//		http.sendPost(url2, url, loginParams);
//
//		// 3. success then go to gmail.
//		// String result = http.GetPageContent(gmail);
//		// System.out.println(result);
//	}
//
//	private void sendPost(String login, String thread,
//			List<NameValuePair> loginParams) throws Exception {
//
//		HttpPost post = new HttpPost(login);
//
//		post.setEntity(new UrlEncodedFormEntity(loginParams, "UTF-8"));
//
//		HttpResponse response = client.execute(post);
//		HttpEntity entity = response.getEntity();
//
//		List<NameValuePair> postParams = getPostFormParams(GetPageContent(url),
//				"was ein kackfred");
//
//		HttpPost post2 = new HttpPost(thread);
//		post2.setEntity(new UrlEncodedFormEntity(postParams, "UTF-8"));
//
//		HttpResponse postResponse = client.execute(post2);
//		HttpEntity postEntity = postResponse.getEntity();
//
//		// int responseCode = conn.getResponseCode();
//		// List<String> list = conn.getHeaderFields().get("Set-Cookie");
//		System.out.println("\nSending 'POST' request to URL : " + login);
//		System.out.println("Post parameters : " + loginParams);
//		System.out.println("\nSending 'POST' request to URL : " + thread);
//		System.out.println("Post parameters : " + postParams);
//		// System.out.println("Response Code : " + responseCode);
//
//		if (entity != null) {
//			InputStream instream = entity.getContent();
//			try {
//
//			} finally {
//				instream.close();
//			}
//		}
//
//	}
//
//	private String GetPageContent(String url) throws Exception {
//
//		HttpGet get = new HttpGet(url);
//		HttpResponse response = client.execute(get);
//		
//		return EntityUtils.toString(response.getEntity());
//
//	}
//
//	public List<NameValuePair> getFormParams(String html, String username,
//			String password) throws UnsupportedEncodingException {
//
//		System.out.println("Extracting form's data...");
//
//		Document doc = Jsoup.parse(html);
//
//		// Google form id
//		Elements loginform = doc.getElementsByTag("form");
//		Elements inputElements = loginform.get(0).getElementsByTag("input");
//		String crypt = inputElements.get(0)
//				.getElementsByAttributeValue("name", "crypt").val();
//		List<NameValuePair> paramList = new ArrayList<NameValuePair>();
//		for (Element inputElement : inputElements) {
//			String key = inputElement.attr("name");
//			String value = inputElement.attr("value");
//
//			if (!key.equals("")) {
//				if (key.equals("user_name"))
//					value = username;
//				else if (key.equals("user_passwd"))
//					value = password;
//				else if (key.equals("crypt"))
//					value = crypt;
//				else if (key.equals("post"))
//					value = "1";
//				paramList.add(new BasicNameValuePair(key, value));
//			}
//		}
//
//		// build parameters list
//
//		return paramList;
//	}
//
//	public List<NameValuePair> getPostFormParams(String html, String text)
//			throws UnsupportedEncodingException {
//
//		System.out.println("Extracting form's data...");
//
//		Document doc = Jsoup.parse(html);
//
//		// Google form id
//		Elements postForm = doc.getElementsByTag("form");
//		Elements inputElements = postForm.get(0).getElementsByTag("input");
//		String crypt = inputElements.get(0)
//				.getElementsByAttributeValue("name", "crypt").val();
//		Element textArea = postForm.get(0).getElementById("post_text_0");
//		List<NameValuePair> paramList = new ArrayList<NameValuePair>();
//		for (Element inputElement : inputElements) {
//			String key = inputElement.attr("name");
//			String value = inputElement.attr("value");
//
//			if (!key.equals("")) {
//				if (key.equals("post_text_0"))
//					value = text;
//				else if (key.equals("crypt"))
//					value = crypt;
//				else if (key.equals("post"))
//					value = "1";
//				paramList.add(new BasicNameValuePair(key, value));
//			}
//		}
//		
//		paramList.add(new BasicNameValuePair("post_text_0", text));
//
//		// build parameters list
//
//		return paramList;
//	}
//
//	public List<String> getCookies() {
//		return cookies;
//	}
//
//	public void setCookies(List<String> cookies) {
//		this.cookies = cookies;
//	}
//
//}
