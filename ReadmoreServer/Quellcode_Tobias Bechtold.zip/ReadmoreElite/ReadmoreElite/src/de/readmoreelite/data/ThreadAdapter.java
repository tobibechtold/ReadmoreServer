package de.readmoreelite.data;

import java.util.List;

import de.readmoreelite.model.Forum;
import de.readmoreelite.model.RMStatus;
import de.readmoreelite.model.RMThread;
import android.R;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class ThreadAdapter extends ArrayAdapter<RMThread> {
	
	private List<RMThread> itemList;
	private Context context;

	public ThreadAdapter(Context context,
			int textViewResourceId, List<RMThread> objects) {
		
		super(context, textViewResourceId, objects);
		this.itemList = objects;
		this.context = context;
	}
	
	public int getCount() {
		return itemList.size();
	}
	
	public long getItemId(int position) {
		
		return itemList.get(position).getId();
	}
	
	@Override
	public RMThread getItem(int position) {
		// TODO Auto-generated method stub
		if(itemList != null) {
			return itemList.get(position);
		}
		return null;
	}
	
	@Override
	public boolean hasStableIds() {
		
		return true;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View v = convertView;
		if (v == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = inflater.inflate(R.layout.two_line_list_item, null);
		}
		
		RMThread c = itemList.get(position);
		TextView text = (TextView) v.findViewById(R.id.text1);
		if(c.getRead() == RMStatus.READ || c.getRead() == RMStatus.STICKY_READ) {
			text.setTypeface(null, Typeface.NORMAL);
		}
		else {
			text.setTypeface(null, Typeface.BOLD);
		}
		text.setText(c.getTitel());
		return v;
	}

	public List<RMThread> getItemList() {
		return itemList;
	}

	public void setItemList(List<RMThread> itemList) {
		this.itemList = itemList;
	}

	
}
